let body = document.querySelector('body')
function dardMode() {
    body.style.backgroundColor = "#000";
    body.style.color = "#fff";
}

function lightMode() {
    body.style.backgroundColor = "#fff";
    body.style.color = "#000";

}